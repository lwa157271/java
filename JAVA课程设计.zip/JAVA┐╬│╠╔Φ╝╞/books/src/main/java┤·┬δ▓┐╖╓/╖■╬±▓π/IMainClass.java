package service;

public interface IMainClassService
{
    void main();
}
